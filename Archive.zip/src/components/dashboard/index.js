import React, { Component } from 'react';

class Dashboard extends Component {
	render() {
		return(
			<div>
				Dashboard Container
			</div>
		)
	}
}

export default Dashboard;